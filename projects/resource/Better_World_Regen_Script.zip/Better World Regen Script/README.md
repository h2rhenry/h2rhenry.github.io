\## Better World Regen Script | Lời nói đầu

&#x20;Đây là tài nguyên miễn phí, nếu có ai bán nó hãy liên hệ qua discord @h2r.henry

&#x20;Tải xuống tại https://h2rhenry.github.io/projects



\## Hướng dẫn sử dụng

&#x20;# Máy chủ cần có: Skript | SkBee | MultiVerse-Core | EzCountdown

&#x20;Thả tệp "Skript/scripts/wregen.sk" vào thư mục skript của máy chủ. Sau đó vào console nhập "/skript reload wregen"

&#x20;Sau khi reload tệp script, sẽ có hướng dẫn setup. Nếu muốn đếm ngược bắt đầu chạy vào đúng 0h hôm nay thì nhập "/wregen setup 0", còn không thì "/wregen setup 1" để tính đếm ngược kể từ 0h ngày hôm sau. Người dùng có thể tùy chỉnh múi giờ tại hàm "set {\_vn\_ts} to {\_now\_ts} + 25200" -  Mặc định của hàm sẽ là múi giờ tại Việt Nam. Người dùng cũng có thể tùy chỉnh một số thứ cần thiết cho máy chủ ở đầu file (on script load).



&#x20;# Tùy chọn thêm: Thanh BossBar đếm ngược tái tạo thế giới

&#x20;Progress sẽ được tính bằng Math API để tăng tính đẹp mắt.

&#x20;Bạn có thể tùy chỉnh bossbar theo kiểu progress sau đó thêm mã progress dưới đây vào: "%math\_0\_(({ezcountdown\_wregen\_days}\*1440)+({ezcountdown\_wregen\_hours}\*60)+{ezcountdown\_wregen\_minutes})/10080\*100%"

&#x20;Lưu ý là cần có Math PlaceholderAPI để bossbar chạy đúng. Sau đó hãy thêm dòng "display-condition: "%world%=<Thế giới bạn cần tái tạo>"" vào dưới tùy chọn bossbar, nếu bạn dùng TAB để tạo bossbar nó sẽ work 100% còn plugin khác thì tôi không chắc.

&#x20;

\## Lưu ý thêm: \*Bạn cần tắt tính năng xác nhận bằng OTP của MV-Core bản mới, bạn cũng có thể tùy chỉnh dòng "execute console command "spawn %loop-player%"" để có thể đưa người chơi đến chỗ an toàn.



