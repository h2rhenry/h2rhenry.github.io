\## Chat Manager Script | Lời nói đầu

&#x20;Đây là tài nguyên miễn phí, nếu có ai bán nó hãy liên hệ qua discord @h2r.henry

&#x20;Tải xuống tại https://h2rhenry.github.io/projects



\## Hướng dẫn cài đặt

Thả files `Skript/scripts/ChatFilter.sk` và `Skript/scripts/mention\_manager.sk` vào thư mục plugin. Sau đó nhập lệnh /skript reload scripts



Bạn có thể vào file ChatFilter để bổ sung thêm từ ngữ bị cấm và tùy chỉnh mức phạt cho người chơi.



Nếu bạn có các plugin quản lí mention khác, hãy tắt nó đi để tính năng này có thể hoạt động tốt.

