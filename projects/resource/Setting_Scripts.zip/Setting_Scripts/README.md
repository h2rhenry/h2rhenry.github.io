\## Setting Script | Lời nói đầu

&#x20;Tài nguyên này là miễn phí để sử dụng, nếu bạn thấy ai đó bán vật phẩm này hãy liên hệ discord @h2r.henry

&#x20;Tải xuống tại https://h2rhenry.github.io/projects/



\## Hướng dẫn

&#x20;Bỏ các tệp vào thư mục máy chủ giống y như đường dẫn. Reload DeluxeMenus và Skript.

&#x20;Tính năng cần các plugin: Skript; SkBee; Skript-reflect; SkPlaceholder; DeluxeMenus; PlaceholderAPI; Protocollib.

&#x20;

