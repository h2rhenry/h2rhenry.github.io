package me.henry.hreconbow.commands;

import me.henry.hreconbow.managers.BossBarManager;
import me.henry.hreconbow.managers.ConfigManager;
import me.henry.hreconbow.managers.MessageManager;
import me.henry.hreconbow.managers.ReconBowManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class hBowCommand implements CommandExecutor, TabCompleter {

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("hreconbow.admin") && !sender.isOp()) {
            sender.sendMessage(MessageManager.get("no-permission"));
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(ChatColor.RED + "--- ☢ Cung Do Thám ☢ ---");
            sender.sendMessage(ChatColor.GRAY + "/hbow give <player> [so_luong]");
            sender.sendMessage(ChatColor.GRAY + "/hbow take <player> [so_luong]");
            sender.sendMessage(ChatColor.GRAY + "/hbow reload");
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            ConfigManager.init();
            MessageManager.init();
            BossBarManager.init();
            sender.sendMessage(MessageManager.get("reload-success"));
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Sai cu phap! Vui long dung /hbow help");
            return true;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(MessageManager.get("player-offline"));
            return true;
        }

        int amount = 1;
        if (args.length >= 3) {
            try {
                amount = Integer.parseInt(args[2]);
                if (amount <= 0) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "So luong phai la mot so nguyen duong!");
                return true;
            }
        }

        if (args[0].equalsIgnoreCase("give")) {
            ItemStack bow = ReconBowManager.createBow();
            bow.setAmount(amount);
            target.getInventory().addItem(bow);

            String msg = MessageManager.get("give-success")
                    .replace("%amount%", String.valueOf(amount))
                    .replace("%player%", target.getName());
            sender.sendMessage(msg);
            return true;
        }

        if (args[0].equalsIgnoreCase("take")) {
            int removed = 0;
            for (ItemStack item : target.getInventory().getContents()) {
                if (ReconBowManager.isReconBow(item)) {
                    int toRemove = Math.min(item.getAmount(), amount - removed);
                    item.setAmount(item.getAmount() - toRemove);
                    removed += toRemove;
                    if (removed >= amount) break;
                }
            }

            String msg = MessageManager.get("take-success")
                    .replace("%amount%", String.valueOf(removed))
                    .replace("%player%", target.getName());
            sender.sendMessage(msg);
            return true;
        }

        return false;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        List<String> completions = new ArrayList<>();

        if (!sender.hasPermission("hreconbow.admin") && !sender.isOp()) return completions;

        if (args.length == 1) {
            completions.addAll(Arrays.asList("give", "take", "reload", "help"));
        }
        else if (args.length == 2 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("take"))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                completions.add(p.getName());
            }
        }
        else if (args.length == 3 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("take"))) {
            completions.addAll(Arrays.asList("1", "2", "5", "16", "32", "64"));
        }

        return completions.stream()
                .filter(s -> s.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                .collect(Collectors.toList());
    }
}