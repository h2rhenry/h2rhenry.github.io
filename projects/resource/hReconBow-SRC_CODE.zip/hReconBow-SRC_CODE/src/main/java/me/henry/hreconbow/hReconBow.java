package me.henry.hreconbow;

import me.henry.hreconbow.commands.hBowCommand;
import me.henry.hreconbow.listeners.ReconBowListener;
import me.henry.hreconbow.managers.BossBarManager;
import me.henry.hreconbow.managers.ConfigManager;
import me.henry.hreconbow.managers.MessageManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class hReconBow extends JavaPlugin {

    private static hReconBow instance;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();
        ConfigManager.init();
        MessageManager.init();
        BossBarManager.init();

        getServer().getPluginManager().registerEvents(new ReconBowListener(), this);

        if (getCommand("hbow") != null) {
            hBowCommand cmd = new hBowCommand();
            getCommand("hbow").setExecutor(cmd);
            getCommand("hbow").setTabCompleter(cmd);
        }

        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new me.henry.hreconbow.hooks.hReconBowExpansion().register();
            getLogger().info("Da tich hop PlaceholderAPI thanh cong!");
        }

        getLogger().info("hReconBow v2.0 da kich hoat!");
    }

    @Override
    public void onDisable() {
        BossBarManager.cleanup();
    }

    public static hReconBow getInstance() {
        return instance;
    }
}