package me.henry.hreconbow.hooks;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.henry.hreconbow.managers.CooldownManager;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class hReconBowExpansion extends PlaceholderExpansion {

    @Override
    public @NotNull String getIdentifier() { return "hreconbow"; }

    @Override
    public @NotNull String getAuthor() { return "Henry"; }

    @Override
    public @NotNull String getVersion() { return "2.0.0"; }

    @Override
    public boolean persist() { return true; }

    @Override
    public @Nullable String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "";

        if (params.equalsIgnoreCase("cooldown")) {
            if (CooldownManager.isOnCooldown(player)) {
                return String.format("%.1f", CooldownManager.getCooldownLeft(player));
            } else {
                return "0";
            }
        }
        return null;
    }
}