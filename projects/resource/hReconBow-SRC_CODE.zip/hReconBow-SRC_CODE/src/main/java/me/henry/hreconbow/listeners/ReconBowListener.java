package me.henry.hreconbow.listeners;

import me.henry.hreconbow.hReconBow;
import me.henry.hreconbow.managers.ConfigManager;
import me.henry.hreconbow.managers.CooldownManager;
import me.henry.hreconbow.managers.MessageManager;
import me.henry.hreconbow.managers.ReconBowManager;
import me.henry.hreconbow.tasks.ReconArrowTask;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.ItemStack;

public class ReconBowListener implements Listener {

    @EventHandler
    public void onShoot(EntityShootBowEvent e) {
        if (!ReconBowManager.isReconBow(e.getBow())) return;
        if (!(e.getProjectile() instanceof Arrow arrow)) return;
        if (!(e.getEntity() instanceof LivingEntity shooter)) return;

        if (shooter instanceof Player p) {
            if (!p.isOp() && !p.hasPermission("hreconbow.bypass")) {
                if (CooldownManager.isOnCooldown(p)) {
                    e.setCancelled(true);
                    double timeLeft = CooldownManager.getCooldownLeft(p);
                    String msg = MessageManager.getRaw("cooldown-warning")
                            .replace("%time%", String.format("%.1f", timeLeft));
                    p.sendActionBar(msg);
                    return;
                }
                CooldownManager.setCooldown(p);
            }
        }

        if (!ConfigManager.isConsumeArrow()) e.setConsumeItem(false);

        new ReconArrowTask(arrow, shooter).runTaskTimer(
                hReconBow.getInstance(), 1L, ConfigManager.getInterval()
        );
    }

    @EventHandler
    public void onEnchant(EnchantItemEvent e) {
        if (ConfigManager.isPreventEnchant() && ReconBowManager.isReconBow(e.getItem())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        if (!ConfigManager.isPreventEnchant()) return;

        ItemStack item1 = e.getInventory().getItem(0);
        ItemStack item2 = e.getInventory().getItem(1);

        if (ReconBowManager.isReconBow(item1) || ReconBowManager.isReconBow(item2)) {
            e.setResult(null);
        }
    }
}