package me.henry.hreconbow.managers;

import me.henry.hreconbow.hReconBow;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BossBarManager {
    private static BossBar scanBar;
    private static final Map<UUID, Long> scannedPlayers = new HashMap<>();
    private static BukkitTask cleanupTask;

    public static void init() {
        cleanup();
        String title = MessageManager.getRaw("bossbar-title");
        BarColor color = BarColor.valueOf(ConfigManager.getBarColor().toUpperCase());
        BarStyle style = BarStyle.valueOf(ConfigManager.getBarStyle().toUpperCase());
        scanBar = Bukkit.createBossBar(title, color, style);

        cleanupTask = Bukkit.getScheduler().runTaskTimer(hReconBow.getInstance(), () -> {
            long now = System.currentTimeMillis();
            scannedPlayers.entrySet().removeIf(entry -> {
                if (now > entry.getValue()) {
                    Player p = Bukkit.getPlayer(entry.getKey());
                    if (p != null) scanBar.removePlayer(p);
                    return true;
                }
                return false;
            });
        }, 10L, 10L);
    }

    public static void addPlayer(Player p, int durationTicks) {
        scannedPlayers.put(p.getUniqueId(), System.currentTimeMillis() + (durationTicks * 50L));
        scanBar.addPlayer(p);
    }

    public static void cleanup() {
        if (cleanupTask != null) cleanupTask.cancel();
        if (scanBar != null) scanBar.removeAll();
        scannedPlayers.clear();
    }
}