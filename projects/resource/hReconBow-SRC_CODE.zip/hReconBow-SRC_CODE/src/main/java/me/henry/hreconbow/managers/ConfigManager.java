package me.henry.hreconbow.managers;

import me.henry.hreconbow.hReconBow;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class ConfigManager {

    private static final int LATEST_VERSION = 1;

    private static FileConfiguration config;
    private static boolean consumeArrow;
    private static int cooldown;
    private static boolean preventEnchant;

    private static double radius;
    private static double depth;
    private static int interval;
    private static int glowDuration;
    private static String particleName;

    private static String barColor;
    private static String barStyle;
    private static int barDuration;

    public static void init() {
        File file = new File(hReconBow.getInstance().getDataFolder(), "config.yml");
        if (!file.exists()) hReconBow.getInstance().saveResource("config.yml", false);
        config = YamlConfiguration.loadConfiguration(file);

        int currentVersion = config.getInt("config-version", 0);
        if (currentVersion < LATEST_VERSION) {
            hReconBow.getInstance().getLogger().warning("====================================================");
            hReconBow.getInstance().getLogger().warning("CẢNH BÁO: Tệp config.yml của bạn đã cũ (v" + currentVersion + ")!");
            hReconBow.getInstance().getLogger().warning("Phiên bản mới nhất là v" + LATEST_VERSION + ".");
            hReconBow.getInstance().getLogger().warning("Plugin đã tự đắp thêm các dòng thiếu, nhưng tốt nhất");
            hReconBow.getInstance().getLogger().warning("bạn nên xóa file config.yml cũ để plugin tạo lại!");
            hReconBow.getInstance().getLogger().warning("====================================================");
        }

        try {
            InputStream defStream = hReconBow.getInstance().getResource("config.yml");
            if (defStream != null) {
                YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(defStream, StandardCharsets.UTF_8));
                config.setDefaults(defConfig);
                config.options().copyDefaults(true);
                config.save(file);
            }
        } catch (IOException e) {
            hReconBow.getInstance().getLogger().warning("Không thể tự động cập nhật config.yml!");
        }

        config = YamlConfiguration.loadConfiguration(file);

        consumeArrow = config.getBoolean("mechanics.consume-arrow", false);
        cooldown = config.getInt("mechanics.cooldown", 10);
        preventEnchant = config.getBoolean("mechanics.prevent-enchant", true);

        radius = config.getDouble("scan.radius", 12.0);
        depth = config.getDouble("scan.depth", 30.0);
        interval = config.getInt("scan.interval", 5);
        glowDuration = config.getInt("scan.glowing-duration", 100);
        particleName = config.getString("scan.particle", "SWEEP_ATTACK");

        barColor = config.getString("bossbar.color", "RED");
        barStyle = config.getString("bossbar.style", "SOLID");
        barDuration = config.getInt("bossbar.duration", 100);
    }

    public static boolean isConsumeArrow() { return consumeArrow; }
    public static int getCooldown() { return cooldown; }
    public static boolean isPreventEnchant() { return preventEnchant; }

    public static double getRadius() { return radius; }
    public static double getDepth() { return depth; }
    public static int getInterval() { return interval; }
    public static int getGlowDuration() { return glowDuration; }
    public static String getParticleName() { return particleName; }

    public static String getBarColor() { return barColor; }
    public static String getBarStyle() { return barStyle; }
    public static int getBarDuration() { return barDuration; }

    public static FileConfiguration getConfig() { return config; }
}