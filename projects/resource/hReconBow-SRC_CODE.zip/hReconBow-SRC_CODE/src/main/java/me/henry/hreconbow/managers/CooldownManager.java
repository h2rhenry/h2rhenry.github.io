package me.henry.hreconbow.managers;

import org.bukkit.entity.Player;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {
    private static final Map<UUID, Long> cooldowns = new HashMap<>();

    public static void setCooldown(Player player) {
        int seconds = ConfigManager.getCooldown();
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis() + (seconds * 1000L));
    }

    public static boolean isOnCooldown(Player player) {
        return cooldowns.containsKey(player.getUniqueId()) && cooldowns.get(player.getUniqueId()) > System.currentTimeMillis();
    }

    public static double getCooldownLeft(Player player) {
        if (!isOnCooldown(player)) return 0.0;
        long timeLeft = cooldowns.get(player.getUniqueId()) - System.currentTimeMillis();
        return timeLeft / 1000.0;
    }
}