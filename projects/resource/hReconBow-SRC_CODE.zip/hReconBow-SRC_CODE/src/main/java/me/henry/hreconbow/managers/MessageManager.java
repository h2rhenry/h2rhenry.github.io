package me.henry.hreconbow.managers;

import me.henry.hreconbow.hReconBow;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class MessageManager {

    private static final Map<String, String> messages = new HashMap<>();
    private static String prefix = "";

    public static void init() {
        File file = new File(hReconBow.getInstance().getDataFolder(), "messages.yml");
        if (!file.exists()) hReconBow.getInstance().saveResource("messages.yml", false);
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);

        try {
            InputStream defStream = hReconBow.getInstance().getResource("messages.yml");
            if (defStream != null) {
                YamlConfiguration defConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(defStream, StandardCharsets.UTF_8));
                config.setDefaults(defConfig);
                config.options().copyDefaults(true);
                config.save(file);
            }
        } catch (IOException e) {
            hReconBow.getInstance().getLogger().warning("Khong the tu dong cap nhat messages.yml!");
        }

        config = YamlConfiguration.loadConfiguration(file);
        messages.clear();

        prefix = config.getString("prefix", "&8[&chReconBow&8] ");

        for (String key : config.getKeys(false)) {
            if (key.equals("prefix")) continue;
            messages.put(key, config.getString(key));
        }
    }

    public static String get(String key) {
        String msg = messages.getOrDefault(key, "&cThieu thong bao: " + key);
        return ChatColor.translateAlternateColorCodes('&', prefix + msg);
    }

    public static String getRaw(String key) {
        String msg = messages.getOrDefault(key, "&cThieu thong bao: " + key);
        return ChatColor.translateAlternateColorCodes('&', msg);
    }
}