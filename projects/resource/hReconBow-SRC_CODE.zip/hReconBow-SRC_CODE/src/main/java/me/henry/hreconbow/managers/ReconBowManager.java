package me.henry.hreconbow.managers;

import me.henry.hreconbow.hReconBow;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.stream.Collectors;

public class ReconBowManager {
    public static final NamespacedKey BOW_KEY = new NamespacedKey(hReconBow.getInstance(), "is_recon_bow");

    public static ItemStack createBow() {
        var section = ConfigManager.getConfig().getConfigurationSection("bow-item");

        Material mat = Material.matchMaterial(section.getString("material", "BOW"));
        if (mat == null) mat = Material.BOW;

        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();

        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', section.getString("display-name")));
            meta.setLore(section.getStringList("lore").stream()
                    .map(s -> ChatColor.translateAlternateColorCodes('&', s))
                    .collect(Collectors.toList()));

            meta.setUnbreakable(section.getBoolean("unbreakable", true));
            if (section.getBoolean("hide-attributes", true)) meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            if (section.getBoolean("hide-enchantments", true)) meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

            meta.getPersistentDataContainer().set(BOW_KEY, PersistentDataType.BYTE, (byte) 1);
            item.setItemMeta(meta);
        }
        return item;
    }

    public static boolean isReconBow(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(BOW_KEY, PersistentDataType.BYTE);
    }
}