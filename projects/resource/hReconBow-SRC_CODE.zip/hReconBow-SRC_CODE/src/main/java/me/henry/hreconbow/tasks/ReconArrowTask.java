package me.henry.hreconbow.tasks;

import me.henry.hreconbow.managers.BossBarManager;
import me.henry.hreconbow.managers.ConfigManager;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;

import java.util.Collection;

public class ReconArrowTask extends BukkitRunnable {
    private final Arrow arrow;
    private final LivingEntity shooter;
    private final double radius;
    private final double depth;
    private final int glowDuration;

    public ReconArrowTask(Arrow arrow, LivingEntity shooter) {
        this.arrow = arrow;
        this.shooter = shooter;
        this.radius = ConfigManager.getRadius();
        this.depth = ConfigManager.getDepth();
        this.glowDuration = ConfigManager.getGlowDuration();
    }

    @Override
    public void run() {
        if (arrow.isDead() || arrow.isOnGround() || arrow.isInBlock()) {
            this.cancel();
            return;
        }

        Location loc = arrow.getLocation();

        BoundingBox box = new BoundingBox(
                loc.getX() - radius,
                loc.getY() - depth,
                loc.getZ() - radius,
                loc.getX() + radius,
                loc.getY() + 1.0,
                loc.getZ() + radius
        );

        try {
            Particle p = Particle.valueOf(ConfigManager.getParticleName().toUpperCase());
            loc.getWorld().spawnParticle(p, loc, 1, 0, 0, 0, 0);
        } catch (IllegalArgumentException ex) {
        }

        Collection<Entity> targets = loc.getWorld().getNearbyEntities(box);

        for (Entity ent : targets) {
            if (!(ent instanceof LivingEntity target)) continue;
            if (target.equals(shooter)) continue;
            if (target.isDead()) continue;

            target.addPotionEffect(new PotionEffect(
                    PotionEffectType.GLOWING,
                    glowDuration,
                    0,
                    false,
                    false
            ));

            if (target instanceof Player p) {
                BossBarManager.addPlayer(p, ConfigManager.getBarDuration());
            }
        }
    }
}